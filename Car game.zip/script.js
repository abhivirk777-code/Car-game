const car = document.getElementById("car");
const obstacle = document.getElementById("obstacle");
const scoreText = document.getElementById("score");
const leftBtn = document.getElementById("left");
const rightBtn = document.getElementById("right");

let carLeft = 125;
let obstacleTop = -100;
let obstacleLeft = 125;
let score = 0;

leftBtn.onclick = function () {
    if (carLeft > 0) {
        carLeft -= 50;
        car.style.left = carLeft + "px";
    }
};

rightBtn.onclick = function () {
    if (carLeft < 250) {
        carLeft += 50;
        car.style.left = carLeft + "px";
    }
};

function moveObstacle() {
    obstacleTop += 5;
    obstacle.style.top = obstacleTop + "px";

    // Collision detection
    if (
        obstacleTop > 390 &&
        obstacleTop < 480 &&
        obstacleLeft === carLeft
    ) {
        alert("Game Over!\nScore: " + score);
        location.reload();
        return;
    }

    // Obstacle reached bottom
    if (obstacleTop > 500) {
        obstacleTop = -100;
        obstacleLeft = Math.floor(Math.random() * 6) * 50;
        obstacle.style.left = obstacleLeft + "px";

        score++;
        scoreText.innerText = score;
    }

    requestAnimationFrame(moveObstacle);
}

moveObstacle();